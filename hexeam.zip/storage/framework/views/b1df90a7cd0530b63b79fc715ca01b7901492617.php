
<html>
<h1>hai..<?php echo e(session('username')); ?></h1>
<thead><h3><b>Details</b></h3><thead><br>

<tbody>
                   <tr>
                   <td><?php echo e($detail->name); ?></td><br>
                   <td><?php echo e($detail->email); ?></td><br>
                   <td><?php echo e($detail->dob); ?></td><br>
                   
                  <td> <?php echo e($detail->mobile_number); ?></td><br><br>
                  </tr>
 <td>
                        <a href="<?php echo e(url('logout')); ?>" class="btn btnsmall  btn-outline-secondary btn-icon-text">
                          logout
                          <i class="ti-file btn-icon-append"></i>                          
                        </a>
                        </td>             
                       
                           <tbody>

<?php /**PATH C:\xampp\htdocs\hexeam\resources\views/employee/view.blade.php ENDPATH**/ ?>