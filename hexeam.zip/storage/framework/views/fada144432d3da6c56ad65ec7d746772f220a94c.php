<html>
<head>
<Link rel="stylesheet" href="<?php echo e(url('assets/css/style.css')); ?>">
</head>
<form action="<?php echo e(url('employee_login_post')); ?>" method="post" enctype="multipart/form-data"><?php echo e(csrf_field()); ?>

<body>

  
<h1><b>EMPLOYEE LOGIN</b></h2>
  <div class="container">

    
    <label for="username"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="username" required>

    <label for="password"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" required>

    <button type="submit">Login</button>
  </div>

  
</form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\hexeam\resources\views/employee/index.blade.php ENDPATH**/ ?>