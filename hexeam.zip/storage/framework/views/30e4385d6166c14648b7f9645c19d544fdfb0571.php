
<html>
<head>
<Link rel="stylesheet" href="<?php echo e(url('assets/css/style.css')); ?>">
</head>
<form action="<?php echo e(url('login')); ?>" method="post" enctype="multipart/form-data"><?php echo e(csrf_field()); ?>

<body>

  

  <div class="container">

    
    <label for="uname"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="username" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" required>

    <button type="submit">Login</button>
  </div>

  
</form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\hexeam\resources\views/admin/index.blade.php ENDPATH**/ ?>