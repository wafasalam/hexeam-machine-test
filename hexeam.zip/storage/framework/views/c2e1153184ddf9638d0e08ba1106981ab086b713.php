<!DOCTYPE html>
<head>
<body>
<form action="<?php echo e(url('update')); ?>" method="post" enctype="multipart/form-data"><?php echo e(csrf_field()); ?>

<fieldset>
<input type="hidden" name="id"value="<?php echo e($edit->id); ?>">
<label>Code:</label>
<input type="text" name="code"  value="<?php echo e($edit->employee_code); ?>" readonly="true"><br>

<label>role:</label>
<select name="title">


 <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <?php if($edit->role_id==$rol->id): ?>
 <option value="<?php echo e($rol->id); ?>" selected><?php echo e($rol->role_title); ?></option>
 <?php endif; ?>
<option value="<?php echo e($rol->id); ?>"><?php echo e($rol->role_title); ?></option>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</select>

<label>Name:</label>
<input type="text" name="name" value="<?php echo e($edit->name); ?>"><br>

<label>DOB:</label>
<input type="text" name="dob"value="<?php echo e($edit->dob); ?>"><br>

<label>Email:</label>
<input type="text" name="email"value="<?php echo e($edit->email); ?>"><br>

<label>Mobile number:</label>
<input type="text" name="mobno"value="<?php echo e($edit->mobile_number); ?>"><br>

<label>Username:</label>
<input type="text" name="uname"value="<?php echo e($edit->username); ?>"><br>

<label>Password:</label>
<input type="text" name="password"value="<?php echo e($edit->password); ?>"><br>

<div class="col-md-12">
                        <div class="form-group row">
                          <label class="col-sm-2 col-form-label">Image:</label>
                          <div class="col-sm-9">
                            <input type="file" class="form-control" id="image" name="image"value="<?php echo e($edit->profile_image); ?>">
               
                          </div>
                        </div>
                        </div><br><br>
<button type="submit" class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn">SUBMIT</button>
</fieldset>
</form>
</head>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\hexeam\resources\views/admin/edit.blade.php ENDPATH**/ ?>