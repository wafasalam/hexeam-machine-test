
<h1>hai..<?php echo e(session('username')); ?></h1>

<a href="admin/create" class="btn btnsmall  btn-outline-secondary btn-icon-text">
                          create  employee
                          <i class="ti-file btn-icon-append"></i>                          
                        </a>
                       
 <table class="table table-hover" id="value-table">
                      <thead>
                        <tr>
                          <th>Code</th>&nbsp;&nbsp;
                          <th>Role</th>&nbsp;&nbsp;
                          <th>Name</th>&nbsp;&nbsp;
                          <th>DOB</th>&nbsp;&nbsp;
                          <th>Username</th>&nbsp;&nbsp;
                          <th>Password</th>&nbsp;&nbsp;
                          <th>E-mail</th>&nbsp;&nbsp;
                          <th>Mobile</th>&nbsp;&nbsp;
                          <th>Image</th>&nbsp;&nbsp;
                        </tr>
                      </thead>
                      <tbody>
                           
                        <?php if(count($Employee)): ?>
                        <?php $__currentLoopData = $Employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($user->employee_code); ?></td>
                          <?php $__currentLoopData = $user->employee_role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <td><?php echo e($emp->emp_name); ?></td>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                        
                           <td><?php echo e($user->name); ?></td>&nbsp;&nbsp;
                           <td><?php echo e($user->dob); ?></td>&nbsp;&nbsp;
                           <td><?php echo e($user->username); ?></td>&nbsp;&nbsp;
                           <td><?php echo e($user->password); ?></td>&nbsp;&nbsp;
                           <td><?php echo e($user->email); ?></td>&nbsp;&nbsp;
                           <td><?php echo e($user->mobile_number); ?></td>&nbsp;&nbsp;
                           <td><img src="<?php echo e(url('employee/'.$user->profile_image)); ?>" width="150" height="100"></td>
                              <td>
                        <a href="<?php echo e(url('edit/'.$user->id)); ?>" class="btn btnsmall  btn-outline-secondary btn-icon-text">
                          edit
                          <i class="ti-file btn-icon-append"></i>                          
                        </a>
                        </td>         
                         <td>
                        <a href="<?php echo e(url('delete/'.$user->id)); ?>" class="btn btnsmall  btn-outline-secondary btn-icon-text">
                          delete
                          <i class="ti-file btn-icon-append"></i>                          
                        </a>
                        </td>                    
                          <td> 
                          </td>
                          </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>                                        
                      </tbody>
                    </table><?php /**PATH C:\xampp\htdocs\hexeam\resources\views/admin/login.blade.php ENDPATH**/ ?>